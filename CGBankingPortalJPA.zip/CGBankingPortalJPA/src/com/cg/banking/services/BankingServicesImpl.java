package com.cg.banking.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.AccountDAO;
import com.cg.banking.daoservices.AccountDAOImpl;
import com.cg.banking.daoservices.TransactionDAO;
import com.cg.banking.daoservices.TransactionDAOImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

@Component("bankingServices")
public  class BankingServicesImpl implements BankingServices{
	
	@Autowired
	AccountDAO customerData1;//=new AccountDAOImpl() ;
	
	@Autowired
	TransactionDAO transactionDAO;//=new TransactionDAOImpl();
	
	private final static float minBalance=500;
	private final static int minAttempt=3;	

	public Account openAccount(String accountType, float initBalance)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		if(initBalance<=minBalance)
			throw new InvalidAmountException("maintain minimum balance");
		Account cust = customerData1.save(new Account(accountType,initBalance));
		transactionDAO.save(cust, cust.getAccountNo(), new Transaction(initBalance, "Deposit"));

		return cust;
	}

	public float withdrawAmount(long accountNo, float amount, int pinNumber) throws InsufficientAmountException,
	AccountNotFoundException, InvalidPinNumberException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED")) {
			throw new AccountBlockedException("account is blocked");
		}
		else if(customers.getPinNumber()!=pinNumber) {
			Account.incrementAttempt();
			System.out.println("No. Of Pin Attempts remaining "+(minAttempt-customers.getAttempt()));
			if(customers.getAttempt()==minAttempt) {
				customers.setAccountStatus("Blocked");
				throw new AccountBlockedException("Due to 3 Incorrect pins Account is blocked");
			}
			else {
				throw new InvalidPinNumberException("invalid pin number");
			}
		}
		else if(customers.getAccountBalance()-amount<=minBalance) {
			throw new InsufficientAmountException("insufficient amount");
		}
		else {
			customers.setAccountBalance(customers.getAccountBalance()-amount);
		}
		customerData1.update(customers);
		transactionDAO.save(customers, customers.getAccountNo(), new Transaction(amount, "Withdraw"));
		return customers.getAccountBalance();
	}
//	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
//
//		Account customers=null;
//		customers=customerData1.findOne(accountNo);
//		if(customers==null)
//			throw new AccountNotFoundException("account not found");
//		transactionDAO.update(accountNo, transaction);
//		return customers;
//	}
	
	public Account getAccountDetails(long accountNo) throws AccountNotFoundException, BankingServicesDownException {
		
				Account customers=null;
				customers=customerData1.findOne(accountNo);
				if(customers==null)
					throw new AccountNotFoundException("account not found");
//				transactionDAO.update(accountNo, transaction);
				return customers;
			}

	public List<Account> getAllAccountDetails() throws BankingServicesDownException {

		List<Account>customers=customerData1.findAll();
		return customers;
	}

	public List<Transaction> getAccountAllTransactions(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transaction = transactionDAO.findAll(accountNo);
		return transaction;
	}

	public String accountStatus(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException,AccountBlockedException {
		Account customers=customerData1.findOne(accountNo);
		if(customers==null)
			throw new AccountNotFoundException("account not found");
		else if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED!"))
			throw new AccountBlockedException("account is blocked");
		return customers.getAccountStatus();
	}

	public float depositAmount(long accountNo, float amount)
			throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		Account customers=null;
		customers=getAccountDetails(accountNo);
		if(customers.getAccountStatus().equalsIgnoreCase("BLOCKED!"))
			throw new AccountBlockedException("account is blocked");
		else
			customers.setAccountBalance(customers.getAccountBalance()+amount);
		customerData1.update(customers);
		transactionDAO.save(customers, customers.getAccountNo(), new Transaction(amount, "Deposit"));
		return customers.getAccountBalance() ;
	}

	public boolean fundTransfer(long accountNoTo, long accountNoFrom, float transferAmount, int pinNumber)
			throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
			BankingServicesDownException, AccountBlockedException {
		Account customerTo=null;
		Account customerFrom=null;
		customerTo=getAccountDetails(accountNoTo);
		customerFrom=getAccountDetails(accountNoFrom);
		if(customerFrom.getAccountBalance()-transferAmount<=minBalance)
			throw new InsufficientAmountException("insufficient amount");
		if(customerFrom.getPinNumber()!=pinNumber)
			throw new InvalidPinNumberException("invalid pin");
		else {
			customerFrom.setAccountBalance(withdrawAmount(customerFrom.getAccountNo(),transferAmount,customerFrom.getPinNumber()));
			customerTo.setAccountBalance(depositAmount(customerTo.getAccountNo(),transferAmount));
			return true;
		}
	}
	public BankingServicesImpl(AccountDAO mockAccountDao) {
		// TODO Auto-generated constructor stub
	}

	public BankingServicesImpl() {
		// TODO Auto-generated constructor stub
	}

}
